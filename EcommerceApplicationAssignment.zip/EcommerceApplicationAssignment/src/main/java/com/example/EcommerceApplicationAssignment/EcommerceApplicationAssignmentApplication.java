package com.example.EcommerceApplicationAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceApplicationAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceApplicationAssignmentApplication.class, args);
	}

}
